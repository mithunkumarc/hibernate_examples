package com.worldclock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="workerdetail")
public class WorkerDetail {
	@Id
    @Column(name="worker_id", unique=true, nullable=false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long workerId;
 
    @Column(name="street")
    private String street;
 
    @Column(name="city")
    private String city;
 
    @Column(name="state")
    private String state;
 
    @Column(name="country")
    private String country;
 
    @OneToOne
    @PrimaryKeyJoinColumn
    private Worker worker;
 
    public WorkerDetail() {
 
    }
 
    public WorkerDetail(String street, String city, String state, String country) {
        this.street = street;
        this.city = city;
        this.state = state;
        this.country = country;
    }

	public Long getWorkerId() {
		return workerId;
	}

	public void setWorkerId(Long workerId) {
		this.workerId = workerId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Worker getWorker() {
		return worker;
	}

	public void setWorker(Worker worker) {
		this.worker = worker;
	}
}
