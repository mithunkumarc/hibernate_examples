package com.worldclock;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata; 
import org.hibernate.boot.MetadataSources; 
import org.hibernate.boot.registry.StandardServiceRegistry; 
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
 
public class ManageWorker {
	private static SessionFactory sf;
	private static StandardServiceRegistry standardServiceRegistry;
	  

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		try {
			 standardServiceRegistry = new StandardServiceRegistryBuilder()
			            .configure() 
			            .build(); 
			        // Create MetadataSources 
			        MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			        // Create Metadata 
			        Metadata metadata = metadataSources.getMetadataBuilder().build();
			        // Create SessionFactory 
			        sf = metadata.getSessionFactoryBuilder().build();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		System.out.println("Example : Hibernate One to One Mapping  using Annotation ");
		Session session = sf.openSession();
		session.beginTransaction();

		WorkerDetail workerDetail = new WorkerDetail("Richmond Town", "Bangalore",
				"Karnataka", "India");
		
		//For passing Date of birth as String
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dob=null;
		try {
			dob = sdf.parse("1987-05-21");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		Worker worker = new Worker("ram", "prased",dob,
				"919595959595");
		worker.setWorkerDetail(workerDetail);
		workerDetail.setWorker(worker);

		session.save(worker);
		
		
		TypedQuery<Worker> query = session.createQuery("FROM Worker");
		 List<Worker> workerList = query.getResultList();

		//List<Worker> workerList = session.createQuery("from Worker").list();
		for (Worker work1 : workerList) {
			System.out.println(work1.getFirstname() + " , "
					+ work1.getLastname() + ", "
					+ work1.getWorkerDetail().getState());
		}

		session.getTransaction().commit();
		session.close();

	}
}
