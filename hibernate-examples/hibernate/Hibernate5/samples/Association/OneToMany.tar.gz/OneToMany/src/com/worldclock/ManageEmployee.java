package com.worldclock;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class ManageEmployee {
	private static SessionFactory sf;
	private static StandardServiceRegistry standardServiceRegistry;

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		try {
			standardServiceRegistry = new StandardServiceRegistryBuilder()
		            .configure() 
		            .build(); 
		        // Create MetadataSources 
		        MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
		        // Create Metadata 
		        Metadata metadata = metadataSources.getMetadataBuilder().build();
		        // Create SessionFactory 
		        sf = metadata.getSessionFactoryBuilder().build();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		System.out.println("Hibernate One to Many Mapping Example Using Annotation ");
		Session session = sf.openSession();
		session.beginTransaction();
		
		Address address = new Address();
		address.setStreet("sindhiya street");
		address.setCity("Gwalior");
		address.setState("Madhya Pradesh");
		address.setCountry("India");
        session.save(address);
 
        Employee e1 = new Employee("Ankit", "Sharma", "9999999999");
        Employee e2 = new Employee("Ankit", "Kaushal", "3333333333");
 
        e1.setAddress(address);
        e2.setAddress(address);
 
        session.save(e1);
        session.save(e2);
 
        session.getTransaction().commit();
        session.close();
	}
}
