package net.codejava.hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

/**
 * A program that demonstrates using JPA annotations to map
 * a bidirectional many-to-many association in Hibernate framework.
 * 
 */
public class UsersManager {

	public static void main(String[] args) {
		// loads configuration and mappings
		ServiceRegistry standardServiceRegistry = new StandardServiceRegistryBuilder()
		            .configure() 
		            .build(); 
		        // Create MetadataSources 
		        MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
		        // Create Metadata 
		        Metadata metadata = metadataSources.getMetadataBuilder().build();
		        // Create SessionFactory 
		        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
		// obtains the session
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Group groupAdmin = new Group("Administrator Group");
		Group groupGuest = new Group("Guest Group");
		
		User user1 = new User("Tom", "tomcat", "tom@codejava.net");
		User user2 = new User("Mary", "mary", "mary@codejava.net");
		
		groupAdmin.addUser(user1);
		groupAdmin.addUser(user2);
		
		groupGuest.addUser(user1);
		
		user1.addGroup(groupAdmin);
		user2.addGroup(groupAdmin);
		user1.addGroup(groupGuest);
		
		session.save(groupAdmin);
		session.save(groupGuest);
		
		session.getTransaction().commit();
		session.close();		
	}

}