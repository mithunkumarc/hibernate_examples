import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata; 
import org.hibernate.boot.MetadataSources; 
import org.hibernate.boot.registry.StandardServiceRegistry; 
import org.hibernate.boot.registry.StandardServiceRegistryBuilder; 
 
public class HibernateConnector {
	 private static StandardServiceRegistry standardServiceRegistry;
	  private static SessionFactory sessionFactory;
	   public static SessionFactory getSessionFactory(){
		   try{
		    	  
			   standardServiceRegistry = new StandardServiceRegistryBuilder()
			            .configure() 
			            .build(); 
			        // Create MetadataSources 
			        MetadataSources metadataSources = new MetadataSources(standardServiceRegistry);
			        // Create Metadata 
			        Metadata metadata = metadataSources.getMetadataBuilder().build();
			        // Create SessionFactory 
			        sessionFactory = metadata.getSessionFactoryBuilder().build();
					return sessionFactory;
		      }catch (Throwable ex) { 
		         System.err.println("Failed to create sessionFactory object." + ex);
		         throw new ExceptionInInitializerError(ex); 
		      }
	   }
}
