package com.worldclock;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class ManageEmployee {
	private static SessionFactory sf;
	private static ServiceRegistry serviceRegistry;

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		try {
			Configuration configuration = new Configuration();
			configuration.configure();
			serviceRegistry = new ServiceRegistryBuilder().applySettings(
					configuration.getProperties()).buildServiceRegistry();
			sf = configuration.buildSessionFactory(serviceRegistry);
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		System.out.println("Hibernate One to Many Mapping Example Using Annotation ");
		Session session = sf.openSession();
		session.beginTransaction();
		
		Address address = new Address();
		address.setStreet("sindhiya street");
		address.setCity("Gwalior");
		address.setState("Madhya Pradesh");
		address.setCountry("India");
        session.save(address);
 
        Employee e1 = new Employee("Ankit", "Sharma", "9999999999");
        Employee e2 = new Employee("Ankit", "Kaushal", "3333333333");
 
        e1.setAddress(address);
        e2.setAddress(address);
 
        session.save(e1);
        session.save(e2);
 
        session.getTransaction().commit();
        session.close();
	}
}
