package com.worldclock;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "address")
public class Address {
@Id
@GeneratedValue
@Column(name = "address_id")
private Long addressId;

@Column(name = "street")
private String street;

@Column(name = "city")
private String city;

@Column(name = "state")
private String state;

@Column(name = "country")
private String country;

@OneToMany(mappedBy = "address")
private Set<Employee> employees;

public Long getAddressId() {
return addressId;
}

public void setAddressId(Long addressId) {
this.addressId = addressId;
}

public String getStreet() {
return street;
}

public void setStreet(String street) {
this.street = street;
}

public String getCity() {
return city;
}

public void setCity(String city) {
this.city = city;
}

public String getState() {
return state;
}

public void setState(String state) {
this.state = state;
}

public String getCountry() {
return country;
}

public void setCountry(String country) {
this.country = country;
}

public Set<Employee> getEmployees() {
return employees;
}

public void setEmployees(Set<Employee> employees) {
this.employees = employees;
}

}
