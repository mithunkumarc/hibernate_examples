package com.worldclock;
import com.worldclock.*;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class ManageWorker {
	private static SessionFactory sf;
	private static ServiceRegistry serviceRegistry;

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		try {
			Configuration configuration = new Configuration();
			configuration.configure();
			serviceRegistry = new ServiceRegistryBuilder().applySettings(
					configuration.getProperties()).buildServiceRegistry();
			sf = configuration.buildSessionFactory(serviceRegistry);
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		System.out.println("Example : Hibernate One to One Mapping  using Annotation ");
		Session session = sf.openSession();
		session.beginTransaction();

		WorkerDetail workerDetail = new WorkerDetail("Lake Town", "Kolkata",
				"West Bengal", "India");
		
		//For passing Date of birth as String
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dob=null;
		try {
			dob = sdf.parse("1987-05-21");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		Worker worker = new Worker("Sushmita", "Dasgupta",dob,
				"919595959595");
		worker.setWorkerDetail(workerDetail);
		workerDetail.setWorker(worker);

		session.save(worker);

		List<Worker> workerList = session.createQuery("from Worker").list();
		for (Worker work1 : workerList) {
			System.out.println(work1.getFirstname() + " , "
					+ work1.getLastname() + ", "
					+ work1.getWorkerDetail().getState());
		}

		session.getTransaction().commit();
		session.close();

	}
}
